#include <iostream>
using namespace std;

void printVector(int rows, int vector[10]) {
    for (int i = 0; i < rows; ++i) {
        cout << vector[i] << " ";
    }
    cout << endl;
}

int main() {
    int rows, cols;
    cout << "Enter the number of rows and columns for the matrix: ";
    cin >> rows >> cols;

    int matrix[10][10], vector[10], result[10] = {0};

    cout << "Enter elements of the matrix:\n";
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> matrix[i][j];
        }
    }

    cout << "Enter elements of the column vector:\n";
    for (int i = 0; i < cols; ++i) {
        cin >> vector[i];
    }

    // Matrix and column vector multiplication
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            result[i] += matrix[i][j] * vector[j];
        }
    }

    cout << "Result of matrix and column vector multiplication:\n";
    printVector(rows, result);

    return 0;
}
