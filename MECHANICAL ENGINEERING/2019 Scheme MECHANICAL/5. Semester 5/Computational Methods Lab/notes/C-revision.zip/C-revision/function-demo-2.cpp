#include <iostream>
using namespace std;

void calculate(int a, int b, int &sum, int &product) {
    sum = a + b;
    product = a * b;
}

int main() {
    int num1, num2;
    cout << "Enter two numbers: ";
    cin >> num1 >> num2;

    int sum1, product1;
    calculate(num1, num2, sum1, product1);

    cout << "The sum of " << num1 << " and " << num2 << " is " << sum1 << endl;
    cout << "The product of " << num1 << " and " << num2 << " is " << product1 << endl;

    return 0;
}
