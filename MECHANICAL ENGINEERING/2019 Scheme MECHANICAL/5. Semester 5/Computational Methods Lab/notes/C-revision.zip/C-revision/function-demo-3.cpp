#include <iostream>
using namespace std;

// Function to add two numbers
int add(int a, int b) {
    return a + b;
}

// Function to multiply two numbers
int multiply(int a, int b) {
    return a * b;
}

// Function that takes another function as input
int performOperation(int x, int y, int (*op)(int, int)) {
    return op(x, y);
}

int main() {
    int num1, num2;
    cout << "Enter two numbers: ";
    cin >> num1 >> num2;

    // Perform addition
    int sum = performOperation(num1, num2, add);
    cout << "The sum of " << num1 << " and " << num2 << " is " << sum << endl;

    // Perform multiplication
    int product = performOperation(num1, num2, multiply);
    cout << "The product of " << num1 << " and " << num2 << " is " << product << endl;

    return 0;
}
