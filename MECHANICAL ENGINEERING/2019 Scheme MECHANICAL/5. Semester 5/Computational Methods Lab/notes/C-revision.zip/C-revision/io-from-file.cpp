#include <iostream>
#include <fstream>
using namespace std;

int main() {
    // Variables for input and output
    ifstream inputFile("input.txt");
    ofstream outputFile("output.txt");

    // Check if the input file opened successfully
    if (!inputFile) {
        cerr << "Unable to open input file." << endl;
        return 1;
    }

    // Check if the output file opened successfully
    if (!outputFile) {
        cerr << "Unable to open output file." << endl;
        return 1;
    }

    int number;
    int sum = 0;

    // Read numbers from the input file and calculate the sum
    while (inputFile >> number) {
        sum += number;
    }

    // Write the sum to the output file
    outputFile << "The sum of the numbers is: " << sum << endl;

    // Close the files
    inputFile.close();
    outputFile.close();

    cout << "The sum has been calculated and written to output.txt" << endl;

    return 0;
}
