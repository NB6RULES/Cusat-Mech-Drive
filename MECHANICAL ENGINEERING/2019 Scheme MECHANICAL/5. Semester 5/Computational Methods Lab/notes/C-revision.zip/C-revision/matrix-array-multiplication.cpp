#include <iostream>
using namespace std;

void printMatrix(int rows, int cols, int matrix[10][10]) {
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int rows, cols;
    cout << "Enter the number of rows and columns for the matrix: ";
    cin >> rows >> cols;

    int matrix[10][10], array[10], result[10][10];

    cout << "Enter elements of the matrix:\n";
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            cin >> matrix[i][j];
        }
    }

    cout << "Enter elements of the array:\n";
    for (int i = 0; i < cols; ++i) {
        cin >> array[i];
    }

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            result[i][j] = matrix[i][j] * array[j];
        }
    }

    cout << "Result of matrix and array multiplication:\n";
    printMatrix(rows, cols, result);

    return 0;
}
