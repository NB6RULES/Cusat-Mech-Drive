#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a positive integer: ";
    cin >> n;

    int i = 1;
    cout << "Numbers from 1 to " << n << ": ";
    do {
        cout << i << " ";
        ++i;
    } while (i <= n);
    cout << endl;

    return 0;
}
