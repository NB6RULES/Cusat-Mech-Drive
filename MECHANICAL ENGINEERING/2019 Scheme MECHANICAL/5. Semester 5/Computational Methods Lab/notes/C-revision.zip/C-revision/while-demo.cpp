#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter a positive integer: ";
    cin >> n;

    int i = 1;
    cout << "Numbers from 1 to " << n << ": ";
    while (i <= n) {
        cout << i << " ";
        ++i;
    }
    cout << endl;

    return 0;
}
