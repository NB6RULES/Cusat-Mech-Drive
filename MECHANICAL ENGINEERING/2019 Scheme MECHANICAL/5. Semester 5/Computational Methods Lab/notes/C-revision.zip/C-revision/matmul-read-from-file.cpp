#include <iostream>
#include <fstream>
use namspace std;
int main() {
    int i, j, k, n;
    float a[10][10], b[10][10], c[10][10] = {0}; // Initialize c with 0s

    cout << "\n  MATRIX MULTIPLICATION  \n";
    cout << "\nWhat is the size of the system (n)?\n";
    cin >> n;

    cout << "\nInput Matrix from the file\n";
    ifstream f("A.txt");
    ifstream ff("B.txt");

    if (!f.is_open() || !ff.is_open()) {
        cerr << "Error opening file(s)." << endl;
        return 1;
    }

    for (i = 0; i < n; ++i)
        for (j = 0; j < n; ++j)
            f >> a[i][j];

    for (i = 0; i < n; ++i)
        for (j = 0; j < n; ++j)
            ff >> b[i][j];

    cout << "\nMatrix A:\n";
    for (i = 0; i < n; ++i) {
        for (j = 0; j < n; ++j) {
            cout << a[i][j] << " ";
        }
        cout << endl;
    }

    cout << "\nMatrix B:\n";
    for (i = 0; i < n; ++i) {
        for (j = 0; j < n; ++j) {
            cout << b[i][j] << "  ";
        }
        cout << endl;
    }

    for (i = 0; i < n; ++i) {
        for (j = 0; j < n; ++j) {
            for (k = 0; k < n; ++k) {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }

   cout << "\nProduct of the matrix C = A * B\n";
    for (i = 0; i < n; ++i) {
        for (j = 0; j < n; ++j) {
            cout << c[i][j] << "  ";
        }
        cout << endl;
    }

    return 0;
}

